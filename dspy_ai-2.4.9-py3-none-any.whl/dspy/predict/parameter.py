class Parameter:
    pass

class Hyperparameter:
    pass
